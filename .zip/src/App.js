import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Signup from "./components/Auth/Signup";
import Login from "./components/Auth/Login";
import ResetPassword from "./components/Auth/ResetPassword";
import Dashboard from "./components/Dashboard/Dashboard"; // Create this path
import FundWallet from "./components/Dashboard/FundWallet";
import { ToastContainer } from "react-toastify";


function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Signup />} />
        <Route path="/login" element={<Login />} />
        <Route path="/reset" element={<ResetPassword />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/fund-wallet" element={<FundWallet />} />
      </Routes>
      <ToastContainer position="top-right" />
    </Router>
  );
}

export default App;
