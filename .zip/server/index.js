const express = require("express");
const cors = require("cors");
const admin = require("firebase-admin");
require("dotenv").config();

const app = express();
const port = process.env.PORT || 5000;

// Configure CORS with your deployed frontend URL(s).
const allowedOrigins = (process.env.FRONTEND_URL || "http://localhost:3000")
  .split(",")
  .map((url) => url.trim())
  .filter(Boolean);

app.use(cors({ origin: allowedOrigins, credentials: false }));

// IMPORTANT: Paystack webhook signature verification needs the RAW request body.
// Keep this route before express.json().
const verifyPaymentRoute = require("./routes/verifyPayment");
const webhookRoute = require("./routes/paystackWebhook");
app.post("/api/paystack/webhook", express.raw({ type: "application/json" }), webhookRoute);

app.use(express.json());

function initializeFirebaseAdmin() {
  if (admin.apps.length) return;

  if (process.env.FIREBASE_SERVICE_ACCOUNT_JSON) {
    const serviceAccount = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_JSON);
    admin.initializeApp({ credential: admin.credential.cert(serviceAccount) });
    return;
  }

  // Local development fallback. Do NOT commit this file.
  const serviceAccount = require("./serviceAccountKey.json");
  admin.initializeApp({ credential: admin.credential.cert(serviceAccount) });
}

initializeFirebaseAdmin();

app.get("/api/health", (req, res) => {
  res.json({ ok: true, service: "vtu-payment-server" });
});

app.use("/api", verifyPaymentRoute);

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
